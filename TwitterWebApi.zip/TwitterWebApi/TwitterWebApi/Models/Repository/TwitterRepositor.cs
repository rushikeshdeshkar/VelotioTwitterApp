﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace TwitterWebApi.Models.Repository
{
    public class TwitterRepository : ITwitterRepository
    {
        //Public methods start
        public void SaveTweets(string acoounts)
        {
            try
            {
                List<Tweets> listTweet = new List<Tweets>();
                
                string strFeed = GetFeed(acoounts); // Get feed from twitter api
                
                var arrTweet = JsonConvert.DeserializeObject(strFeed);                
                dynamic stuff = JsonConvert.DeserializeObject(arrTweet.ToString());

                for (int i = 0; i < stuff.statuses.Count; i++)
                {
                    string obj = stuff.statuses[i].ToString();
                    Tweets objTweet = JsonConvert.DeserializeObject<Tweets>(obj);
                    SaveFeed(objTweet); // Save feed in db.
                }
            }
            catch (Exception e)
            {
            }
            
        }

        public List<Post> SearchTweets(string searchText)
        {
            try
            {
                List<Post> listPost = GetAllTweets();
                return listPost.Where(x => x.TweetText.Contains(searchText)).ToList();
            }
            catch (Exception e)
            {
                return null; //handle exception ToDo
            }
        }

        public List<Post> GetAllTweets()
        {
            try
            {
                List<Tweets> listtTweets = GetTweets();
                List<User> listUsers = GetUsers();
                List<Post> listPost = (from t in listtTweets
                                       join u in listUsers on t.UserId equals u.Id
                                       select new Post()
                                       {
                                           UserId = u.Id,
                                           UserName = u.Name,
                                           UserDescription = u.Description,
                                           UserProfileImageUrl = u.ProfileImageUrl,
                                           TweetID = t.Id,
                                           TweetText = t.Text,
                                           Retweet_count = t.RetweetCount,
                                           favorite_count = t.FavoriteCount
                                       }
                              ).ToList();
                return listPost;
            }
            catch (Exception e)
            {
                return null; //handle exception ToDo
            }
        }

        //Public methods end


        ////Local methods Start
        private string GetFeed(string accounts)
        {
            string credentials = "YjFCYWJEZkxGVVB5NHg1R0ZjZElOTkNJVjpVMW1kc1duSW50UjF4TmRZc0VPRkpGNTUxNjh0VWxtN1RHZ3hxcUdTSTQ3RjNIazd0YQ==";

            //obtaining access_token

            string access_token = "";
            string strFeed = null;
            var post = WebRequest.Create("https://api.twitter.com/oauth2/token") as HttpWebRequest;
            post.Method = "POST";
            post.ContentType = "application/x-www-form-urlencoded";
            post.Headers[HttpRequestHeader.Authorization] = "Basic " + credentials;
            var reqbody = Encoding.UTF8.GetBytes("grant_type=client_credentials");
            post.ContentLength = reqbody.Length;
            using (var req = post.GetRequestStream())
            {
                req.Write(reqbody, 0, reqbody.Length);
            }
            try
            {
                using (var resp = post.GetResponse().GetResponseStream())//there request sends
                {
                    var respR = new StreamReader(resp);
                    strFeed = respR.ReadToEnd();
                }
                //get token
                access_token = strFeed.Substring(strFeed.IndexOf("access_token\":\"") + "access_token\":\"".Length, strFeed.IndexOf("\"}") - (strFeed.IndexOf("access_token\":\"") + "access_token\":\"".Length));
            }
            catch //if credentials are not valid (403 error)
            {
                return null;
            }
            if (access_token == null || access_token == "")
            {
                return null; //invalid token
            }

            //rest api using
            var gettimeline = WebRequest.Create("https://api.twitter.com/1.1/search/tweets.json?q=" + accounts) as HttpWebRequest;

            gettimeline.Method = "GET";
            gettimeline.Headers[HttpRequestHeader.Authorization] = "Bearer " + access_token;
            try
            {

                using (var resp = gettimeline.GetResponse().GetResponseStream())//there request sends
                {
                    var respR = new StreamReader(resp);
                    strFeed = respR.ReadToEnd();
                }
            }
            catch 
            {
                return null; //invalid feed
            }

            return strFeed;
        }

        private void SaveFeed(Tweets tweet)
        {
            try
            {
                TwitterDBContext db = new TwitterDBContext();

                var order = db.Users.Where(x => x.Name == tweet.User.Name).FirstOrDefault();
                if (order == null)
                {
                    db.Users.Add(tweet.User);
                };


                tweet.UserId = tweet.User.Id;
                var find = db.Tweets.Where(x => x.IdStr  == tweet.IdStr ).FirstOrDefault();
                 if ( find == null)
                {
                    db.Tweets.Add(tweet);
                };

                db.SaveChanges();
            }
            catch (Exception e)
            {
            }
        }

        private List<Tweets> GetTweets()
        {
            try
            {
                TwitterDBContext db = new TwitterDBContext();
                return db.Tweets.ToList();
            }
            catch (Exception e)
            {
                return null; //handle exception ToDo
            }
        }

        private List<User> GetUsers()
        {
            try
            {
            TwitterDBContext db = new TwitterDBContext();
            return db.Users.ToList();
            }
            catch (Exception e)
            {
                return null; //handle exception ToDo
            }
        }
        ////Local methods End


        
    }
}