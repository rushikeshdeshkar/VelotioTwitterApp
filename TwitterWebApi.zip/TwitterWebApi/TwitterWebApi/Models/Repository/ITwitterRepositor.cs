﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterWebApi.Models.Repository
{
    interface ITwitterRepository
    {
        void SaveTweets(string acoounts);
        List<Post> GetAllTweets();
        List<Post> SearchTweets(string search);
    }
}
