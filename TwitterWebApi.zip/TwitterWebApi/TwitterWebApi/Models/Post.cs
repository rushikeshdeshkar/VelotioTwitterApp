﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterWebApi.Models
{
    public class Post
    {
        public int Id { get; set; }
        public long UserId { get; set; }
        public string UserName { get; set; }
        public string UserDescription { get; set; }
        public string UserProfileImageUrl { get; set; }
        public long TweetID { get; set; }
        public string TweetText { get; set; }
        public long Retweet_count { get; set; }
        public long favorite_count { get; set; }
    
    }
}