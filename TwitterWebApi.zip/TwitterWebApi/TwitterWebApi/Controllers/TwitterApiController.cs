﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TwitterWebApi.Models;
using TwitterWebApi.Models.Repository;

namespace TwitterWebApi.Controllers
{
    public class TwitterApiController : ApiController
    {
        private ITwitterRepository Repo; //Interface refrence

         public TwitterApiController()
            : this(new TwitterRepository())
        {

        }

         public TwitterApiController(TwitterRepository repo)
        {
            Repo = repo;
        }

        
        // GET api/twitterapi
         public IEnumerable<Post> Get()
        {
            try
            {
                return Repo.GetAllTweets();
            }
            catch (Exception)
            {
                return null;
            }         

        }

        // POST api/twitterapi
         public HttpResponseMessage Post(object acoounts)
        {
            try
            {
                Repo.SaveTweets((string)acoounts);
                HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, acoounts);
                response.Headers.Location = new Uri(Url.Link("DefaultApi", acoounts));
                return response;
            }
            catch (Exception)
            {
               return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }

        // PUT api/twitterapi/5
         public IEnumerable<Post> Put(object search)
         {
             try
             {
                 return Repo.SearchTweets((string)search);
             }
             catch (Exception)
             {
                 return null;
             } 
         }

    }
}
