﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TwitterTestApp.Models;
using TwitterTestApp.Models.Reository;

namespace TwitterTestApp.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Feed()
        {
            ViewBag.Message = "Save Tweets To Database.";

            return View("Feed");
        }

        [HttpPost]
        public ActionResult Feed(Post objPost)
        {
            // Mention the twitter accont you want to searc here 
            string accounts = "from:virendersehwag+OR+from:ChennaiIPL+OR+from:HRS_Cricket+OR+from:imVkohli";
            //string accounts = "from:imVkohli+OR+from:ImRaina+OR+from:msdhoni+OR+from:virendersehwag";
            TwitterRepository repo = new TwitterRepository();
            repo.SaveTweets(accounts);
            return RedirectToAction("Tweets");
        }

        public ActionResult Tweets()
        {
            ViewBag.Message = "Indian Premier League 2018";
            TwitterRepository reo = new TwitterRepository();
            return View(reo.GetAllTweets());
        }

        [HttpPost]
        public ActionResult Tweets(string searchText)
        {
            ViewBag.Message = "Indian Premier League 2018";
            TwitterRepository reo = new TwitterRepository();
            return View(reo.SearchTweets(searchText));
        }

    }
}
